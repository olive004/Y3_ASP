% ASP CW4: 4.6 sign
function sign_x = sign_asp(x)
    sign_x = abs(x) ./ x;
end